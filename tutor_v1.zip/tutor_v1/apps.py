from django.apps import AppConfig


class TutorV1Config(AppConfig):
    name = 'tutor_v1'
