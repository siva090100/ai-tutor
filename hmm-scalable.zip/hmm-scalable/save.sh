zip hmm.zip *.c* *.h makefile par2seq.sh seq2par.sh
mv hmm.zip ~/Downloads
